# Handoff: VGC Ultraviolet Motion System

## Overview
A lightweight animation system for the VGC PWA (baroda.app, repo `VGC-Reinventing/frontend`). It makes the app feel fluid without new dependencies: directional tab transitions, push/pop, staggered list entrances, a gliding bottom-nav indicator, count-up numerals, press feedback, sheet/dialog entrances, skeleton→content crossfade, pull-to-refresh, bell/badge micro-interactions, two celebration variants, and an optional View Transitions API upgrade.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing intended look and behavior, not production code to copy directly. The task is to **implement these animations in the existing codebase** (`VGC-Reinventing/frontend`: React 18 + Vite + react-router + react-query, styles in plain CSS under `src/styles/`), following its established patterns. This is NOT a new app — it is a motion layer added to an app that already exists and works.

Two of the bundled files ARE intended nearly as-is:
- `motion.css` — drop into `src/styles/motion.css`, import after `primitives.css`. Written against the repo's real tokens (`tokens.css`) and class names (`primitives.css`, `global.css`).
- `MOTION.md` — the implementation guide: per-pattern wiring with concrete TSX patches for `TabLayout.tsx`, `StackLayout.tsx`, `BottomNav.tsx`, `NotifBell.tsx`, plus `useCountUp` and `usePullToRefresh` hooks and the View Transitions snippet.

`VGC Motion System.dc.html` is the interactive demo/spec — open it in a browser to feel every pattern (each spec card has a Replay button; a Tweaks-driven slow-motion multiplier exists in the original project).

## Fidelity
**High-fidelity for motion.** All durations, easings, distances, and choreography are final — implement exactly as specified in MOTION.md's timing table. The demo's visual UI (phone screens) is a faithful recreation of the app's existing Ultraviolet design system purely as context; do not restyle any screens — only add motion.

## Constraints (from the design)
- **No new dependencies.** Plain CSS + a few small hooks. No framer-motion.
- **Transform + opacity only.** Never animate layout properties.
- **Enter-only.** No exit animations that block input or delay navigation.
- **Reuse existing tokens.** `--ease-out (.22,1,.36,1)`, `--ease-spring (.34,1.56,.64,1)`, `--t-fast 140ms`, `--t-med 220ms`, `--t-slow 360ms` — all already in `src/styles/tokens.css`.
- `prefers-reduced-motion` collapses everything to 1ms (already handled in motion.css).

## Patterns & Where They Apply

| # | Pattern | Applies to | Spec |
|---|---------|-----------|------|
| 1 | Directional tab switch | `TabLayout.tsx` (`.screen-enter`) | 260ms, ease-out, x ±16px + fade, enter-only. Direction = tab index delta (see MOTION.md §1) |
| 2 | Push / pop | `StackLayout.tsx` | 320ms, ease-out, x 24px, keyed by pathname |
| 3 | Staggered entrance | `DataView` results, dashboards, RowGroups — add `.stagger` | 420ms rise 12px, 45ms/item, cap 8 |
| 4 | Nav indicator + icon pop | `BottomNav.tsx` | pill glides 350ms spring; active icon scales to 1.22 over 380ms |
| 5 | Count-up numerals | Wallet hero, PTS balances via `<Num>` | 800ms cubic ease-out, rAF, tabular-nums (`useCountUp`) |
| 6 | Press feedback | already on `.vgc-btn`; extend to `.vgc-card--tap` (.98) and `.vgc-row` (.99) | 140ms scale |
| 7 | Sheet & dialog | `Dialog.tsx` + overlay divs | sheet 360ms ease-out rise; dialog 220ms scale .96; backdrop fade 260ms |
| 8 | Skeleton → content | screens using `SkeletonList` | keep shimmer; render arrived content with `.stagger` |
| 9 | Pull to refresh | tab scroll containers (`.vgc-scroll`) | ×0.5 drag resistance, arc rotates 2.6°/px, fires ≥60px (`usePullToRefresh`) |
| 10 | Bell & badge | `NotifBell.tsx` | wiggle 600ms (origin 50% 15%) on count increase; badge spring-pop 380ms |
| 11 | Celebration — member send | transfer sent, points received | check circle stroke-draw 450ms → 8-particle burst 700ms, glow pulse, auto-dismiss 1.7s, violet |
| 12 | Celebration — approval verdict | admin verdicts: declarations, loans, escrow | teal ShieldCheck stamps down (scale 1.9→1, −9°→0, 420ms spring) then stroke-draws, "APPROVED" mono tag, 1.7s |
| 13 | View Transitions API | router (progressive enhancement) | `document.startViewTransition` wrapper; 180/220ms old/new; CSS system is the fallback |

Full timing table, keyframes, and every code patch: **MOTION.md** (authoritative).

## Interactions & Behavior details
- Tab switch direction: screen enters from the side the user navigated toward (+16px when moving to a higher tab index, −16px lower).
- Celebrations never loop and never require dismissal; the wrapper keyframe fades itself out (opacity 0 → 1 at 8% → hold → 0 at 100% over 1700ms). `pointer-events: none` throughout.
- Pull-to-refresh: indicator opacity ramps in over the first 45px; release below threshold springs back with 300ms ease-out; on fire, wire to the screen's react-query `refetch()` and show the existing skeleton state.
- Stagger cap: items ≥8 share the last delay (315ms) so long lists never feel slow.
- Count-up: skip to final value under `prefers-reduced-motion`.

## Design Tokens (all pre-existing in `src/styles/tokens.css`)
Easings: `--ease-out: cubic-bezier(0.22,1,0.36,1)`, `--ease-spring: cubic-bezier(0.34,1.56,0.64,1)`. Durations: `--t-fast 140ms`, `--t-med 220ms`, `--t-slow 360ms`. Celebration colors: violet `#8B5CF6`, positive `#3DDC97`, teal `#2DD4BF`/`#14B8A6`. No new tokens are required.

## Assets
None. Icons are the repo's existing lucide-react set (`ShieldCheck` for the approval celebration, `Bell`, `RefreshCw`).

## Files in this bundle
- `README.md` — this file
- `MOTION.md` — implementation guide with all code patches (start here)
- `motion.css` — the drop-in stylesheet → `src/styles/motion.css`
- `VGC Motion System.dc.html` — interactive demo/spec (design reference; open in a browser)

## Suggested implementation order
1. Add `motion.css` + import (patterns 3, 6, 7, 8 work immediately where classes exist).
2. TabLayout + StackLayout patches (1, 2).
3. BottomNav indicator (4).
4. `useCountUp` in wallet/PTS (5).
5. NotifBell (10).
6. Pull-to-refresh on the main tab screens (9).
7. Celebrations on send-points success and admin approval mutations (11, 12).
8. View Transitions wrapper last (13) — verify no double-animation with `.screen-enter`.
