# VGC Ultraviolet — Motion handoff

Drop-in: add `motion.css` to `src/styles/` and import it after `primitives.css`.
No new dependencies. Everything animates **transform + opacity only** and reuses
the motion tokens already in `tokens.css`.

Live spec/demo: `VGC Motion System.dc.html` (this project).

## 1. Directional tab switch

Today `TabLayout` has a static `.screen-enter`. Two changes:

```tsx
// TabLayout.tsx — key the scroll div by pathname so the animation
// replays on every tab change, and pass a direction.
import { useLocation } from 'react-router-dom';
import { TABS } from '@/routes/tabs';

export function TabLayout() {
  const { pathname } = useLocation();
  const idx = TABS.findIndex((t) => pathname.startsWith(t.to));
  const prev = useRef(idx);
  const dir = idx >= prev.current ? 1 : -1;
  useEffect(() => { prev.current = idx; }, [idx]);
  return (
    <Phone>
      <div key={pathname} className="vgc-screen vgc-scroll screen-enter"
           style={{ '--dx': `${dir * 16}px`, '--dy': '0px' } as CSSProperties}>
        <Outlet />
      </div>
      <BottomNav />
    </Phone>
  );
}
```

## 2. Push / pop

`StackLayout`: add `key={pathname}` and `className="... screen-push"` to the
scroll div. (Pop-direction animation isn't worth the complexity on web —
enter-only reads fine.)

## 3. Staggered entrances

Add `className="stagger"` to list containers — `DataView` results wrapper,
dashboards' card columns, `SkeletonList`'s replacement content. One class,
no per-item work.

## 4. Bottom nav indicator

```tsx
// BottomNav.tsx
const { pathname } = useLocation();
const idx = Math.max(0, TABS.findIndex((t) => pathname.startsWith(t.to)));
return (
  <nav className="vgc-nav" style={{ '--nav-index': idx } as CSSProperties}>
    <span className="vgc-nav-indicator" aria-hidden />
    {TABS.map(...)}  {/* unchanged */}
  </nav>
);
```

## 5. Count-up numerals

```ts
// hooks/useCountUp.ts
import { useEffect, useState } from 'react';

export function useCountUp(target: number, dur = 800) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) { setV(target); return; }
    let raf: number; const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      setV(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, dur]);
  return v;
}
```

Use in wallet hero / PTS balances via `<Num>{useCountUp(balance)}</Num>`.
`<Num>` is already tabular so digits don't jitter while counting.

## 6. Bell & badge

In `NotifBell`, when `count` increases, add `.vgc-bell-ring` to the svg and
remove it on `animationend` (or key the svg by `count`). The badge already
remounts when count goes 0→n, so `.vgc-notif-badge`'s pop plays for free.

## 7. Sheets & dialogs

Add `.vgc-sheet-enter` / `.vgc-dialog-enter` to the Dialog panel and
`.vgc-backdrop-enter` to the overlay div. Enter-only; close can stay instant.

## 8. Celebration (send points / approval success)

```tsx
<div className="vgc-celebrate">          {/* absolute inset-0 overlay */}
  <div className="glow" />               {/* radial violet blob */}
  {PARTICLES.map((p, i) => (
    <span key={i} className="particle" style={{ '--bx': p.x, '--by': p.y, background: p.c }} />
  ))}
  <svg viewBox="0 0 96 96">
    <circle className="draw" cx="48" cy="48" r="40" pathLength="100" stroke="var(--violet-500)" strokeWidth="4" fill="none" strokeLinecap="round" />
    <path className="draw draw--check" d="M32 50 L44 62 L66 38" pathLength="100" stroke="var(--positive)" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
</div>
```

Mount for 1.7s, then unmount (the wrapper fades itself out). Reserve for
money moments only — transfer sent, points received.

**Approval-verdict variant** (declarations, loans, escrow): same overlay with
`className="vgc-celebrate vgc-celebrate--approve"`, teal palette, and a
lucide `ShieldCheck` inside a `.stamp` wrapper instead of the check circle —
it stamps down (scale 1.9 → 1, −9° → 0°) then draws itself. Verdicts read as
official, not festive.

## 9. Pull to refresh

```ts
// hooks/usePullToRefresh.ts — drives --pull (px) on the scroll container.
import { useRef } from 'react';

export function usePullToRefresh(onRefresh: () => void) {
  const y0 = useRef<number | null>(null);
  const set = (el: HTMLElement, v: number) => el.style.setProperty('--pull', String(v));
  return {
    onPointerDown: (e: React.PointerEvent<HTMLElement>) => {
      if (e.currentTarget.scrollTop <= 0) y0.current = e.clientY;
    },
    onPointerMove: (e: React.PointerEvent<HTMLElement>) => {
      if (y0.current == null) return;
      const d = (e.clientY - y0.current) * 0.5;          // resistance
      if (d > 3 && e.currentTarget.scrollTop <= 0) {
        e.currentTarget.classList.remove('vgc-ptr--settling');
        set(e.currentTarget, Math.min(90, d));
      }
    },
    onPointerUp: (e: React.PointerEvent<HTMLElement>) => {
      if (y0.current == null) return;
      const fire = parseFloat(e.currentTarget.style.getPropertyValue('--pull') || '0') >= 60;
      y0.current = null;
      e.currentTarget.classList.add('vgc-ptr--settling');
      set(e.currentTarget, 0);
      if (fire) onRefresh();
    },
  };
}
```

Usage: spread onto the `.vgc-scroll` div; add `touch-action: pan-y` there;
put `<span class="vgc-ptr-indicator">` (with the arc svg) as its first child
and wrap the list in `.vgc-ptr-content`. Wire `onRefresh` to the screen's
react-query `refetch()`.

## 10. View Transitions API (progressive enhancement)

Free cross-fade + shared-element moves on Chrome/Edge/Safari 18+; the CSS
system above remains the fallback everywhere else.

```ts
// lib/navigate.ts — wrap programmatic navigation
import { flushSync } from 'react-dom';

export function withViewTransition(fn: () => void) {
  if (!document.startViewTransition) return fn();
  document.startViewTransition(() => flushSync(fn));
}
// usage: withViewTransition(() => navigate('/wallet'))
```

When a screen animates via view transition, suppress the CSS entrance for
that navigation (add a `data-vt` attr and gate `.screen-enter` on `:not([data-vt])`)
so the two systems never double-animate.

## Timing reference

| Pattern            | Duration | Easing        | Notes                     |
|--------------------|----------|---------------|---------------------------|
| Tab switch         | 260ms    | --ease-out    | x ±16px, enter-only       |
| Push               | 320ms    | --ease-out    | x 24px                    |
| Card stagger       | 420ms    | --ease-out    | 45ms/item, cap 8          |
| Nav indicator      | 350ms    | --ease-spring | translateX glide          |
| Icon pop           | 380ms    | --ease-spring | scale 1.22 peak           |
| Count-up           | 800ms    | cubic ease-out| rAF                       |
| Press              | 140ms    | --ease-out    | scale .97–.99             |
| Sheet              | 360ms    | --ease-out    | translateY                |
| Backdrop           | 260ms    | ease          | opacity                   |
| Bell wiggle        | 600ms    | ease          | rotate, origin top        |
| Badge pop          | 380ms    | --ease-spring | scale spring              |
| Celebration        | 1700ms   | mixed         | auto-dismiss, never loops |
| Approval stamp     | 420ms    | --ease-spring | scale 1.9→1, −9°→0        |
| Pull to refresh    | drag     | --ease-out    | ×0.5 resistance, 60px fire|
| View transition    | 180/220ms| UA default    | old/new root              |
