# Handoff: VGC "Ultraviolet" Redesign (baroda.app)

## Overview
A full visual + IA redesign of the VGC Reinventing PWA (repo: `VGC-Reinventing/frontend`, branch `main`). Goals, from user research: fix low-contrast/small text, make actions visually distinct from navigation, replace the Home shortcut wall with a personal dashboard, and make Community the real hub for games/groups/blog/education. **All existing routes in `src/routes/router.tsx` are kept** — this is a reskin + restructure, not a rewrite.

## About the Design Files
`Baroda Redesign.dc.html` in this bundle is a **design reference created in HTML** — mockups showing intended look, not production code. The task is to **recreate these designs in the existing React + Vite codebase** (`src/`) using its established patterns: `tokens.css` custom properties, the `vgc-*` class system in `global.css`/`primitives.css`, and the existing components (`Btn`, `Card`, `Tabs`, `Badge`, `ScreenHeader`, `BottomNav`, `Icon` with lucide-react). Do NOT copy the mockups' inline styles verbatim — port their values into the token/class system.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii and copy in the mockups are final. Recreate pixel-perfectly using the codebase's components. Every mockup is labeled with an option id (1a–1l, 2a–2r) referenced throughout this doc.

## Where to start (ordered, each step shippable)
1. **Tokens** — replace `src/styles/tokens.css` with the bundled `tokens.css` (same token names, all aliases preserved; adds `--font-display`, `--numeral`, `--focus-ring`, `--grad-inr/token/points`). This alone delivers ~60% of the visual change with zero component edits. Add the Google Fonts `<link>` for Space Grotesk + JetBrains Mono to `index.html` (or keep the `@import`).
2. **Button tiers** (`src/components/Btn.tsx` + `global.css`) — see "Action system" below.
3. **Nav rows ≠ buttons** — restyle the `Action`/`Row` card patterns (WalletScreen.tsx, ProfileScreen.tsx) per "List rows" below.
4. **Screen restructures** — Home (1c), Wallet (1d), Community (1g), then the rest via the coverage map.

## Design Tokens (summary — full file bundled)
Colors (on `--bg-app: #0B0D13`):
- Surfaces: card `#151926`, raised/input `#1D2333`, bars/sticky `#0E1119`, hairline `rgba(148,163,199,.14)`
- Text: `--fg-1 #F2F5FF` (15.4:1), `--fg-2 #DEE4F5` (11.9:1), `--fg-3 #A8B2CC` (7.1:1), `--fg-4 #7E8AA6` (4.6:1). **Nothing renders below 4.5:1.**
- Brand: `--violet-500 #8B5CF6` (primary fill, gradient `135deg #8B5CF6→#6D28D9`), `#C4B5FD` accent text on dark, `#A78BFA` icons
- Semantic: positive `#3DDC97`, negative `#FB7185`, warning `#FBBF24`, info `#38BDF8`
- Wallet card gradients: INR `135deg #0d9488→#115e59`, Tokens `135deg #7C3AED→#4C1D95`, Points `135deg #0284c7→#075985`

Typography:
- **Space Grotesk 700** (`--font-display`): all h1/h2, screen titles, and every numeral (money, balances, counts) with `font-variant-numeric: tabular-nums`
- **Plus Jakarta Sans**: body 16/24 (weight 500), captions **13.5px/500** (up from 12/400 — the single biggest readability fix)
- **JetBrains Mono 600 11px, letter-spacing .18em, uppercase**: section headers/overlines (e.g. "RECENT ACTIVITY", "INR & TOKENS")

Radii: buttons/inputs 14, cards 18, hero cards 20–22, chips pill. Spacing: 4px base, screens padded 22px, card padding 14–18px, list gap 10–12px.

## Action system (the "buttons all look alike" fix)
Three tiers, never mixed:
- **Primary** (max ONE per screen): h 52–54, r 14–15, fill `var(--grad-violet)`, white 700 15–16px, shadow `0 10px 26px rgba(139,92,246,.35)`. E.g. Sign in, Send points, Submit declaration, Add to cart.
- **Secondary**: same size, transparent, `1.5px solid rgba(167,139,250,.5)` border, text `#C4B5FD` 600.
- **Ghost**: no border/fill, text `#A8B2CC` 600 (destructive ghost: `#FB7185`, e.g. Sign out).
- Filter chips: h 32–34 pill; active = solid `#8B5CF6` white 700; inactive = `#151926` + hairline, `#A8B2CC` 600.
- Admin approve: teal fill `135deg #0d9488→#0f766e`; reject: negative-bordered secondary.

## List rows (navigation, NOT buttons)
Rows live inside a grouped card (`#151926`, r 18, hairline border, rows divided by `rgba(148,163,199,.1)`); each row: 36px icon chip (r 11, tinted bg at ~14% of its accent color, accent-colored 16px lucide icon) + title `--fg-1` 600 14.5 + optional sub `--fg-4` 12.5 + right chevron `--fg-4` (or count badge). Replaces today's one-Card-per-Action pattern in WalletScreen/ProfileScreen.

## Inputs
h 54, r 14, bg `#1D2333` (or `#151926`), hairline border; label above: 13px 600 `--fg-3`. Focus: `1.5px solid #8B5CF6` + `box-shadow: var(--focus-ring)`. Amount inputs: Space Grotesk numerals 28px. OTP boxes: 46×56, r 14 (2b). Upload dropzone: dashed `rgba(167,139,250,.4)`, violet-tinted bg (2c).

## Status badges
h 22–24 pill, 700 11–11.5px UPPERCASE, tinted bg at ~13% + full-strength text: PENDING `#FBBF24`, APPROVED/ACTIVE `#3DDC97`, REJECTED/DISPUTE `#FB7185`, INFO/DISPATCHED `#38BDF8`, brand `#C4B5FD` on `rgba(139,92,246,.16)`. Maps to `Badge.tsx` tones + `statusTone.ts`.

## Screens / Views
Refer to the labeled mockups; key structural changes:

- **Home `/home` (1c)** — replaces the 12-button wall. Order: greeting row (small "Good evening" + name in Space Grotesk 22) with search/bell icon buttons (40×40, r 13, `#151926`); TOTAL VALUE hero card (r 22, `--grad-violet-deep`, 38px numeral, three per-currency mini-chips `rgba(255,255,255,.1)`); 4 quick actions (54px icon chips + 12.5px labels: Send, Declare, Convert, Shop); "FOR YOU" horizontal scroll of contextual 250px cards (next session, open election — derive from existing queries); "RECENT ACTIVITY" list (first 2–4 of `useWalletActivity`) with See-all link. All other old shortcuts move to Wallet (money) or Community (social).
- **Wallet `/wallet` (1d)** — segmented control (pill container `#151926` p 4, active segment solid `#8B5CF6`) for Balances|Passbook; 3 gradient balance cards (r 18, overline label + 26px numeral); primary "Send points" + secondary "Declare INR"; grouped nav rows under mono section headers "INR & TOKENS" and "POINTS · PTS · LOANS" (absorbs /pts, /loans, /expenses entries).
- **Passbook (1i)** — day-grouped (mono "TODAY"/"YESTERDAY" headers); each tx: 40px direction chip (green ↙ credit / red ↗ debit), title 15/600, category+time 12.5 `--fg-4`; right: signed amount (Space Grotesk, credits `#3DDC97` with "+", debits `--fg-1` with "−") over running balance in 11.5px mono `#5B647D`. Load-more = secondary button.
- **Market `/explore` (1e)** — renamed "Market". Search field + type chips; **2-col grid** (gap 12) of image-led cards: 110px image (striped placeholder if none), title 14/600, seller·type 12 `--fg-4`, price in Space Grotesk `#C4B5FD`; SOLD OUT badge overlays image, content at 60% opacity. Cart icon button with violet count badge.
- **Item detail (1f)** — 210px image, type + stock badges, 24px Space Grotesk title, seller row with ★ rating `#FBBF24`, body 15/1.6, key-value details card; sticky footer bar (`#0E1119`, top hairline): price block left + primary CTA right.
- **Community `/community` (1g)** — becomes the hub: chips Games|Groups|Blog|Learn (routes to /groups, /blog, /education); live-season banner card (`--grad-card-violet`); YOUR GAMES 2-col cards with status badges; FROM YOUR GROUPS post preview; blog entry row.
- **Send points (1h)** — recipient card (avatar + name + mono member id + Change link); giant centered amount (Space Grotesk 56) + "balance after"; quick-amount chips (selected = violet-tinted with violet border); note input; info notice (`rgba(56,189,248,.08)` bg, blue border/icon); sticky primary "Send N pts".
- **Profile (1j)** — identity card (gradient `#1D2333→#151926`, 58px monogram avatar, name/email/mono id, badge row: VERIFIED green, PIONEER violet, ★ REP amber); grouped rows under ACCOUNT/PRIVACY; guardian approvals row with red count badge; Sign out = red ghost.
- **Auth (1b, 2a, 2b)** — login: violet radial glow at top, 64px "V" logo tile, 32px Space Grotesk heading; signup: 3-segment progress bar, guardian notice (amber tinted card) + guardian email when DOB < 18; verify/2FA: OTP boxes, resend countdown.
- **Course detail (1k)** — enrolled hero (`--grad-card-violet`, progress bar `#3DDC97`); NEXT SESSION card (violet-bordered, date tile, "Check in" primary-sm); ALL SESSIONS rows: green check = attended, red × = missed, neutral = upcoming.
- **Education (2k)** — continue-learning card (green-bordered); catalog cards with 96px covers, price, seat/start badges; dashed "Propose a course" prompt. Teacher dashboard reuses the admin queue pattern (1l).
- **PTS convert (2e)** — two stacked give/get cards with overlapping violet arrow tile (44px, 4px bg-ring); quote card (rate / lock countdown / fee rows, mono values); primary CTA states the full conversion.
- **Cart (2f)** — items grouped by seller (mono headers); qty steppers (30px `#1D2333` tiles); totals card with per-currency subtotals + "after checkout" balances in mono green.
- **Order detail (2g)** — item summary; status banner badge; vertical escrow timeline (24px nodes: green check = done, dashed violet = pending; connectors tinted); primary "Mark received" + danger-secondary "Raise dispute".
- **Notifications (2h)** — NEW (violet-bordered cards, inline Accept/Decline for transfers) vs EARLIER (flat `#11141d`, 75% opacity); preferences link at bottom.
- **Gaming (2i, 2j)** — game hub: 72px logo, pioneer badge, election banner (white CTA on violet gradient), season event rows (date tiles + Join primary-sm), leaderboard rows (rank #1 amber). Election: voting-rights notice; candidate cards (leader violet-bordered w/ focus ring, gradient tally bar + %, Vote primary on leader / secondary on others).
- **Financial (2l)** — investment hero (teal gradient `150deg #134e4a→#0f2e2c`, principal + earned in `#5EEAD4`); Option A/B plan tiles (A green-bordered); sponsorship row with ACTIVE badge.
- **Groups/Blog (2m)** — group header (avatar, members, Invite secondary-sm); composer stub row; post cards: author row (+PINNED badge), body 14/1.55 `--fg-2`, attachment placeholder, SVG heart/reply counts (never emoji).
- **Contracts (2n)** — title + IN PROGRESS badge; CLIENT→PROVIDER tiles with arrow; escrow strip (violet-tinted, "IN ESCROW" + amount + release rule); CONDITIONS checklist (n/m met); "Open chat" primary + "Mark conditions met" secondary; dispute escalation footnote.
- **Expenses (2o)** — month summary card: 30px total, +% vs last month in `#FB7185`, stacked category bar (violet/blue/green segments, 2px gaps) + dot legend; recent rows with status in sub; "Add expense" secondary.
- **Search (2p)** — focused search field in header; results grouped by mono headers (COURSES/MARKETPLACE/BLOG/MEMBERS); match substring highlighted `#C4B5FD`.
- **Admin (1l, 2q)** — console: 3 stat tiles (26px colored numerals), NEEDS ACTION queue rows with colored count badges + SLA hints, MANAGE 2-col grid. Review screens: one card per item (member row, declared amount + ref in key-value strip, proof placeholder, Approve teal / Reject red); processed cards at 85% opacity.

## Interactions & Behavior
- Transitions: reuse `--t-fast/med` + `--ease-out`; primary buttons press to `--violet-600`+scale .98; rows highlight `#1A1F2E` on press.
- Focus: every interactive element gets the violet focus ring (`--focus-ring`); keep Card.tsx TR-247 keyboard behavior.
- Skeletons: keep `Skeleton.tsx`, bg `#151926` shimmer to `#1D2333`.
- Hit targets ≥ 44px throughout (rows are 48–56px).
- PWA/iOS: `viewport-fit=cover`; bottom nav `padding-bottom: calc(10px + env(safe-area-inset-bottom))`; top bar `padding-top: env(safe-area-inset-top)`; sticky bars use opaque `--bg-glass-solid` — **no backdrop-filter on sticky** (known iOS bug, already documented in the old tokens.css).
- Numerals: apply `.numeral` (tabular Space Grotesk) to every amount so columns align.

## State Management
No new state requirements — all screens are recompositions of existing queries in `src/api/queries.ts`. Home's "For you" cards derive from existing data: next enrolled session (education), open elections (gamingElections), pending transfers (pointsTransfer). Total-value hero sums the three wallets client-side (display only; label it "Total value", not a real currency).

## Assets
- Fonts: Space Grotesk (500–700), Plus Jakarta Sans (400–800), JetBrains Mono (500–600) — Google Fonts.
- Icons: lucide-react (already a dependency) — mockup icons are hand-simplified stand-ins; use the real lucide equivalents (house, wallet, shopping-cart, users, user, send, bell, search, chevron-right, arrow-down-left, arrow-up-right, etc.).
- Images: striped placeholders mark real-content slots (item photos, game logos, course covers, proof screenshots).
- No emoji anywhere; reaction counts use lucide heart / message-circle.

## Files
- `Baroda Redesign.dc.html` — all mockups. Turn 1 (1a–1l): design spec + core screens. Turn 2 (2a–2r): full rollout + **2r = route→pattern coverage map** (the implementation checklist tying every route in `router.tsx` to a mockup).
- `tokens.css` — final drop-in replacement for `src/styles/tokens.css`.
